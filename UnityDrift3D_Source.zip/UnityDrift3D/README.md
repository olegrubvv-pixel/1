# Drift Street 3D — Unity Android Prototype

Mobile landscape 3D drift prototype built for Unity 2022.3.74f1.

Core features in this first build:
- touch steering, gas, brake, handbrake and nitro;
- arcade drift physics with controllable counter-steer;
- speed-sensitive chase camera and dynamic FOV;
- tire smoke, skid trails, night city, neon gates and drift arena;
- drift score, combo and nitro HUD;
- 60 FPS mobile target and Android configuration.

The project is procedural: the scene is generated at runtime from Unity primitives, so there are no third-party copyrighted car or environment assets in the repository.
