#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class DriftBuildConfig
{
    [InitializeOnLoadMethod]
    static void Configure()
    {
        PlayerSettings.companyName = "Night Shift Studio";
        PlayerSettings.productName = "Drift Street 3D";
        PlayerSettings.bundleVersion = "0.1.0";
        PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.nightshift.driftstreet3d");
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
        PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
        PlayerSettings.Android.useCustomKeystore = false;
        PlayerSettings.MTRendering = true;
    }
}
#endif
