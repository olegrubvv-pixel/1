using System;
using System.Collections.Generic;
using UnityEngine;

public static class DriftGameBootstrap
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Boot()
    {
        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 0;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Physics.defaultSolverIterations = 8;
        Physics.defaultSolverVelocityIterations = 2;

        var root = new GameObject("Drift Street 3D");
        root.AddComponent<DriftGame>();
    }
}

public class DriftGame : MonoBehaviour
{
    DriftCar car;
    DriftCamera followCam;
    GUIStyle hudStyle, smallStyle, titleStyle, buttonStyle;
    float driftScore;
    float combo = 1f;
    float comboHold;
    float bestDrift;
    float nitro = 1f;
    Material asphaltMat, curbMat, buildingMat, glassMat, neonMat, wheelMat, carMat, skidMat;
    readonly List<GameObject> decorativeCars = new List<GameObject>();

    public float Nitro => nitro;

    void Start()
    {
        SetupEnvironment();
        CreateTrack();
        CreateCity();
        CreateCar();
        CreateCamera();
    }

    Material Mat(Color color, float metallic = 0f, float smoothness = 0.3f, bool emission = false)
    {
        var shader = Shader.Find("Standard");
        var m = new Material(shader);
        m.color = color;
        m.SetFloat("_Metallic", metallic);
        m.SetFloat("_Glossiness", smoothness);
        if (emission)
        {
            m.EnableKeyword("_EMISSION");
            m.SetColor("_EmissionColor", color * 2.4f);
        }
        return m;
    }

    void SetupEnvironment()
    {
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.ExponentialSquared;
        RenderSettings.fogDensity = 0.0035f;
        RenderSettings.fogColor = new Color(0.025f, 0.035f, 0.06f);
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
        RenderSettings.ambientSkyColor = new Color(0.08f, 0.10f, 0.18f);
        RenderSettings.ambientEquatorColor = new Color(0.035f, 0.045f, 0.07f);
        RenderSettings.ambientGroundColor = new Color(0.012f, 0.014f, 0.02f);

        var lightGO = new GameObject("Moon Light");
        var light = lightGO.AddComponent<Light>();
        light.type = LightType.Directional;
        light.color = new Color(0.55f, 0.68f, 1f);
        light.intensity = 0.8f;
        light.shadows = LightShadows.Soft;
        light.transform.rotation = Quaternion.Euler(48f, -28f, 0f);

        asphaltMat = Mat(new Color(0.055f, 0.058f, 0.065f), 0.02f, 0.22f);
        curbMat = Mat(new Color(0.22f, 0.24f, 0.28f), 0.05f, 0.35f);
        buildingMat = Mat(new Color(0.035f, 0.045f, 0.065f), 0.05f, 0.3f);
        glassMat = Mat(new Color(0.04f, 0.12f, 0.18f), 0.15f, 0.85f);
        neonMat = Mat(new Color(0.05f, 0.65f, 1f), 0f, 0.7f, true);
        wheelMat = Mat(new Color(0.015f, 0.015f, 0.018f), 0.1f, 0.18f);
        carMat = Mat(new Color(0.08f, 0.20f, 0.72f), 0.72f, 0.82f);
        skidMat = Mat(new Color(0.01f, 0.01f, 0.012f), 0f, 0.05f);
    }

    GameObject Cube(string name, Vector3 pos, Vector3 scale, Material mat, Transform parent = null)
    {
        var g = GameObject.CreatePrimitive(PrimitiveType.Cube);
        g.name = name;
        g.transform.position = pos;
        g.transform.localScale = scale;
        if (parent) g.transform.SetParent(parent, true);
        var r = g.GetComponent<Renderer>();
        r.material = mat;
        return g;
    }

    void CreateTrack()
    {
        var ground = Cube("Ground", new Vector3(0, -0.55f, 0), new Vector3(420, 1f, 420), Mat(new Color(0.018f,0.024f,0.03f), 0f, 0.15f));
        ground.GetComponent<BoxCollider>().size = Vector3.one;

        // Wide drift arena with a long boulevard, a circular pad and concrete borders.
        Cube("Boulevard", new Vector3(0, 0.01f, 0), new Vector3(34, 0.12f, 300), asphaltMat);
        Cube("Crossroad", new Vector3(0, 0.015f, 30), new Vector3(190, 0.12f, 34), asphaltMat);
        Cube("DriftPad", new Vector3(82, 0.02f, -58), new Vector3(112, 0.13f, 112), asphaltMat);

        for (int i = -7; i <= 7; i++)
        {
            if (i == 0) continue;
            Cube("LaneMark", new Vector3(0, 0.09f, i * 19f), new Vector3(0.15f, 0.02f, 7.5f), neonMat);
        }

        for (int z = -145; z <= 145; z += 10)
        {
            Cube("LeftBarrier", new Vector3(-18.2f, 0.45f, z), new Vector3(0.7f, 0.8f, 8.8f), curbMat);
            Cube("RightBarrier", new Vector3(18.2f, 0.45f, z), new Vector3(0.7f, 0.8f, 8.8f), curbMat);
        }

        for (int x = -90; x <= 90; x += 10)
        {
            Cube("CrossBarrierA", new Vector3(x, 0.45f, 12.2f), new Vector3(8.8f, 0.8f, 0.7f), curbMat);
            Cube("CrossBarrierB", new Vector3(x, 0.45f, 47.8f), new Vector3(8.8f, 0.8f, 0.7f), curbMat);
        }

        // Neon gates make the route readable at speed.
        for (int z = -120; z <= 120; z += 40)
        {
            Cube("GateL", new Vector3(-15.5f, 4f, z), new Vector3(0.35f, 8f, 0.35f), neonMat);
            Cube("GateR", new Vector3(15.5f, 4f, z), new Vector3(0.35f, 8f, 0.35f), neonMat);
            Cube("GateTop", new Vector3(0, 7.7f, z), new Vector3(31.3f, 0.35f, 0.35f), neonMat);
        }
    }

    void CreateCity()
    {
        var rng = new System.Random(7319);
        for (int i = 0; i < 75; i++)
        {
            float side = (i % 2 == 0) ? -1f : 1f;
            float x = side * (30f + (float)rng.NextDouble() * 110f);
            float z = -150f + (float)rng.NextDouble() * 300f;
            float w = 8f + (float)rng.NextDouble() * 15f;
            float d = 8f + (float)rng.NextDouble() * 15f;
            float h = 12f + (float)rng.NextDouble() * 55f;
            var b = Cube("Tower", new Vector3(x, h * 0.5f - 0.05f, z), new Vector3(w, h, d), buildingMat);
            if (i % 3 == 0)
            {
                Cube("Glass", b.transform.position + new Vector3(-side * (w * 0.505f), 0, 0), new Vector3(0.08f, h * 0.78f, d * 0.72f), glassMat);
            }
            if (i % 4 == 0)
            {
                Cube("RoofNeon", new Vector3(x, h + 0.2f, z), new Vector3(w * 0.86f, 0.18f, 0.18f), neonMat);
            }
        }

        // Decorative parked cars.
        for (int i = 0; i < 10; i++)
        {
            float x = (i % 2 == 0 ? -1 : 1) * 25f;
            float z = -100f + i * 23f;
            var p = BuildVisualCar(new Vector3(x, 0.45f, z), Quaternion.Euler(0, i % 2 == 0 ? 0 : 180, 0),
                Mat(Color.HSVToRGB((i * 0.11f) % 1f, 0.55f, 0.8f), 0.55f, 0.72f));
            decorativeCars.Add(p);
        }
    }

    GameObject BuildVisualCar(Vector3 position, Quaternion rotation, Material paint)
    {
        var root = new GameObject("Street Car");
        root.transform.SetPositionAndRotation(position, rotation);
        Cube("LowerBody", position, new Vector3(1.95f, 0.55f, 4.25f), paint, root.transform).transform.localPosition = new Vector3(0,0.15f,0);
        var hood = Cube("Hood", position, new Vector3(1.85f, 0.20f, 1.2f), paint, root.transform); hood.transform.localPosition = new Vector3(0,0.47f,1.25f);
        var cabin = Cube("Cabin", position, new Vector3(1.62f, 0.68f, 1.72f), glassMat, root.transform); cabin.transform.localPosition = new Vector3(0,0.72f,-0.25f);
        var roof = Cube("Roof", position, new Vector3(1.5f, 0.12f, 1.35f), paint, root.transform); roof.transform.localPosition = new Vector3(0,1.06f,-0.28f);
        var spoiler = Cube("Spoiler", position, new Vector3(1.78f, 0.10f, 0.35f), paint, root.transform); spoiler.transform.localPosition = new Vector3(0,0.78f,-1.92f);
        for (int i = 0; i < 4; i++)
        {
            float sx = (i % 2 == 0) ? -1.0f : 1.0f;
            float sz = i < 2 ? 1.35f : -1.35f;
            var w = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            w.name = "Wheel";
            w.transform.SetParent(root.transform, false);
            w.transform.localPosition = new Vector3(sx, 0f, sz);
            w.transform.localRotation = Quaternion.Euler(0,0,90);
            w.transform.localScale = new Vector3(0.42f,0.18f,0.42f);
            w.GetComponent<Renderer>().material = wheelMat;
            Destroy(w.GetComponent<Collider>());
        }
        return root;
    }

    void CreateCar()
    {
        var root = BuildVisualCar(new Vector3(0, 0.7f, -82f), Quaternion.identity, carMat);
        root.name = "Player Car";
        foreach (var childCollider in root.GetComponentsInChildren<Collider>()) Destroy(childCollider);
        var rb = root.AddComponent<Rigidbody>();
        rb.mass = 1320f;
        rb.drag = 0.018f;
        rb.angularDrag = 0.55f;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        rb.centerOfMass = new Vector3(0, -0.34f, -0.1f);
        var col = root.AddComponent<BoxCollider>();
        col.center = new Vector3(0,0f,0);
        col.size = new Vector3(1.9f,0.8f,4.2f);

        car = root.AddComponent<DriftCar>();
        car.game = this;
        car.rb = rb;
        car.ConfigureEffects(skidMat);
    }

    void CreateCamera()
    {
        var camGO = new GameObject("Main Camera");
        camGO.tag = "MainCamera";
        var cam = camGO.AddComponent<Camera>();
        cam.fieldOfView = 68f;
        cam.nearClipPlane = 0.12f;
        cam.farClipPlane = 650f;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.018f, 0.026f, 0.05f);
        cam.allowHDR = true;
        followCam = camGO.AddComponent<DriftCamera>();
        followCam.target = car.transform;
        followCam.targetRb = car.rb;
    }

    public void ConsumeNitro(float amount) { nitro = Mathf.Clamp01(nitro - amount); }

    void Update()
    {
        if (!car) return;
        if (!car.NitroHeld) nitro = Mathf.MoveTowards(nitro, 1f, Time.deltaTime * 0.055f);

        float slip = Mathf.Abs(car.SlipAngle);
        if (car.SpeedKph > 28f && slip > 12f)
        {
            float gain = car.SpeedKph * Mathf.InverseLerp(12f, 42f, slip) * Time.deltaTime;
            combo = Mathf.Min(8f, combo + Time.deltaTime * 0.5f);
            driftScore += gain * combo;
            comboHold = 1.5f;
            bestDrift = Mathf.Max(bestDrift, driftScore);
        }
        else
        {
            comboHold -= Time.deltaTime;
            if (comboHold <= 0f)
            {
                driftScore = Mathf.MoveTowards(driftScore, 0f, Time.deltaTime * 120f);
                combo = Mathf.MoveTowards(combo, 1f, Time.deltaTime * 1.3f);
            }
        }
    }

    void InitGUI()
    {
        if (hudStyle != null) return;
        hudStyle = new GUIStyle(GUI.skin.label) { fontSize = Mathf.RoundToInt(Screen.height * 0.045f), fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft };
        hudStyle.normal.textColor = Color.white;
        titleStyle = new GUIStyle(GUI.skin.label) { fontSize = Mathf.RoundToInt(Screen.height * 0.032f), fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
        titleStyle.normal.textColor = new Color(0.3f,0.86f,1f);
        smallStyle = new GUIStyle(GUI.skin.label) { fontSize = Mathf.RoundToInt(Screen.height * 0.022f), alignment = TextAnchor.MiddleLeft };
        smallStyle.normal.textColor = new Color(0.78f,0.86f,0.96f);
        buttonStyle = new GUIStyle(GUI.skin.box) { fontSize = Mathf.RoundToInt(Screen.height * 0.03f), fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
        buttonStyle.normal.textColor = Color.white;
    }

    void DrawButton(Rect r, string text, bool active)
    {
        var old = GUI.color;
        GUI.color = active ? new Color(0.15f,0.85f,1f,0.88f) : new Color(0.08f,0.12f,0.2f,0.72f);
        GUI.Box(r, text, buttonStyle);
        GUI.color = old;
    }

    void OnGUI()
    {
        if (!car) return;
        InitGUI();
        float h = Screen.height;
        float w = Screen.width;
        GUI.Label(new Rect(w*0.035f,h*0.03f,w*0.32f,h*0.08f), Mathf.RoundToInt(car.SpeedKph) + " km/h", hudStyle);
        GUI.Label(new Rect(w*0.035f,h*0.10f,w*0.34f,h*0.05f), "DRIFT  " + Mathf.RoundToInt(driftScore) + "   x" + combo.ToString("0.0"), smallStyle);
        GUI.Label(new Rect(w*0.035f,h*0.145f,w*0.34f,h*0.05f), "BEST  " + Mathf.RoundToInt(bestDrift), smallStyle);

        float nitroW = w*0.18f;
        GUI.Box(new Rect(w*0.78f,h*0.055f,nitroW,h*0.035f), "");
        var old = GUI.color; GUI.color = new Color(0.12f,0.78f,1f,0.9f);
        GUI.DrawTexture(new Rect(w*0.782f,h*0.058f,(nitroW-4f)*nitro,h*0.029f), Texture2D.whiteTexture);
        GUI.color = old;
        GUI.Label(new Rect(w*0.78f,h*0.01f,nitroW,h*0.04f), "NITRO", titleStyle);

        Rect left = new Rect(w*0.035f,h*0.71f,w*0.12f,h*0.20f);
        Rect right = new Rect(w*0.165f,h*0.71f,w*0.12f,h*0.20f);
        Rect hand = new Rect(w*0.39f,h*0.78f,w*0.14f,h*0.14f);
        Rect brake = new Rect(w*0.70f,h*0.69f,w*0.10f,h*0.14f);
        Rect gas = new Rect(w*0.82f,h*0.66f,w*0.13f,h*0.25f);
        Rect boost = new Rect(w*0.83f,h*0.47f,w*0.11f,h*0.13f);
        DrawButton(left, "◀", car.LeftHeld);
        DrawButton(right, "▶", car.RightHeld);
        DrawButton(hand, "DRIFT", car.HandbrakeHeld);
        DrawButton(brake, "BRAKE", car.BrakeHeld);
        DrawButton(gas, "GAS", car.GasHeld);
        DrawButton(boost, "N2O", car.NitroHeld);
    }
}

public class DriftCar : MonoBehaviour
{
    public Rigidbody rb;
    public DriftGame game;
    public float SpeedKph { get; private set; }
    public float SlipAngle { get; private set; }
    public bool LeftHeld { get; private set; }
    public bool RightHeld { get; private set; }
    public bool GasHeld { get; private set; }
    public bool BrakeHeld { get; private set; }
    public bool HandbrakeHeld { get; private set; }
    public bool NitroHeld { get; private set; }

    float steerInput;
    float throttleInput;
    float brakeInput;
    float handbrake;
    readonly List<ParticleSystem> smoke = new List<ParticleSystem>();
    readonly List<TrailRenderer> trails = new List<TrailRenderer>();

    public void ConfigureEffects(Material skidMaterial)
    {
        Vector3[] rear = { new Vector3(-0.97f, 0.05f, -1.35f), new Vector3(0.97f, 0.05f, -1.35f) };
        foreach (var p in rear)
        {
            var anchor = new GameObject("Rear Tire FX");
            anchor.transform.SetParent(transform, false);
            anchor.transform.localPosition = p;
            var ps = anchor.AddComponent<ParticleSystem>();
            var main = ps.main;
            main.startLifetime = 0.95f;
            main.startSpeed = 1.2f;
            main.startSize = 0.58f;
            main.maxParticles = 180;
            main.simulationSpace = ParticleSystemSimulationSpace.World;
            main.startColor = new Color(0.72f,0.76f,0.82f,0.38f);
            var emission = ps.emission; emission.rateOverTime = 0f;
            var shape = ps.shape; shape.shapeType = ParticleSystemShapeType.Cone; shape.angle = 22f; shape.radius = 0.12f;
            smoke.Add(ps);

            var tr = anchor.AddComponent<TrailRenderer>();
            tr.time = 3.5f;
            tr.startWidth = 0.16f;
            tr.endWidth = 0.06f;
            tr.minVertexDistance = 0.08f;
            tr.material = skidMaterial;
            tr.emitting = false;
            trails.Add(tr);
        }
    }

    void Update()
    {
        ReadInput();
    }

    void ReadInput()
    {
        LeftHeld = RightHeld = GasHeld = BrakeHeld = HandbrakeHeld = NitroHeld = false;
        float w = Screen.width, h = Screen.height;
        foreach (var t in Input.touches)
        {
            if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) continue;
            Vector2 p = t.position;
            float nx = p.x / w;
            float ny = p.y / h;
            // touch Y is bottom-up; HUD rectangles are top-down.
            if (nx < 0.16f && ny < 0.31f) LeftHeld = true;
            if (nx >= 0.16f && nx < 0.30f && ny < 0.31f) RightHeld = true;
            if (nx > 0.81f && ny < 0.35f) GasHeld = true;
            if (nx > 0.68f && nx < 0.82f && ny < 0.34f) BrakeHeld = true;
            if (nx > 0.37f && nx < 0.55f && ny < 0.26f) HandbrakeHeld = true;
            if (nx > 0.80f && ny > 0.38f && ny < 0.56f) NitroHeld = true;
        }

        if (Input.touchCount == 0)
        {
            LeftHeld = Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow);
            RightHeld = Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow);
            GasHeld = Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow);
            BrakeHeld = Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow);
            HandbrakeHeld = Input.GetKey(KeyCode.Space);
            NitroHeld = Input.GetKey(KeyCode.LeftShift);
        }

        steerInput = (LeftHeld ? -1f : 0f) + (RightHeld ? 1f : 0f);
        throttleInput = GasHeld ? 1f : 0f;
        brakeInput = BrakeHeld ? 1f : 0f;
        handbrake = HandbrakeHeld ? 1f : 0f;
        NitroHeld = NitroHeld && GasHeld && game != null && game.Nitro > 0.01f;
    }

    void FixedUpdate()
    {
        if (!rb) return;
        Vector3 localVel = transform.InverseTransformDirection(rb.velocity);
        SpeedKph = rb.velocity.magnitude * 3.6f;
        SlipAngle = Mathf.Atan2(localVel.x, Mathf.Abs(localVel.z) + 0.1f) * Mathf.Rad2Deg;

        float speedFactor = Mathf.Clamp01(SpeedKph / 190f);
        float maxSteer = Mathf.Lerp(2.2f, 0.85f, speedFactor);
        float forwardVel = localVel.z;

        if (throttleInput > 0f && SpeedKph < 235f)
        {
            float engine = Mathf.Lerp(11200f, 4300f, speedFactor);
            rb.AddForce(transform.forward * engine * throttleInput, ForceMode.Force);
        }

        if (brakeInput > 0f)
        {
            if (forwardVel > 1f) rb.AddForce(-transform.forward * 12500f * brakeInput, ForceMode.Force);
            else rb.AddForce(-transform.forward * 6200f * brakeInput, ForceMode.Force);
        }

        if (NitroHeld && game != null)
        {
            rb.AddForce(transform.forward * 12000f, ForceMode.Force);
            game.ConsumeNitro(Time.fixedDeltaTime * 0.13f);
        }

        if (rb.velocity.magnitude > 0.8f)
        {
            float reverseSign = Mathf.Sign(Mathf.Abs(forwardVel) < 0.1f ? 1f : forwardVel);
            rb.AddTorque(Vector3.up * steerInput * maxSteer * reverseSign * (2200f + SpeedKph * 19f), ForceMode.Force);
        }

        // Arcade tire model: front has stronger grip, rear grip drops under handbrake and throttle.
        float rearGrip = Mathf.Lerp(0.78f, 0.18f, handbrake);
        rearGrip *= Mathf.Lerp(1f, 0.72f, throttleInput * Mathf.InverseLerp(35f, 115f, SpeedKph));
        float lateral = localVel.x;
        rb.AddForce(-transform.right * lateral * rb.mass * rearGrip * 5.2f, ForceMode.Force);

        // Yaw stabilizer keeps drift controllable without killing the slide.
        float targetYaw = steerInput * Mathf.Clamp(SpeedKph * 0.24f, 0f, 38f);
        float yaw = rb.angularVelocity.y * Mathf.Rad2Deg;
        float yawAssist = (targetYaw - yaw) * (handbrake > 0f ? 15f : 9f);
        rb.AddTorque(Vector3.up * yawAssist, ForceMode.Force);

        // Downforce and anti-roll style upright correction.
        rb.AddForce(-transform.up * rb.velocity.sqrMagnitude * 2.1f, ForceMode.Force);
        Vector3 tiltAxis = Vector3.Cross(transform.up, Vector3.up);
        rb.AddTorque(tiltAxis * 17000f - new Vector3(rb.angularVelocity.x,0,rb.angularVelocity.z) * 2600f, ForceMode.Force);

        bool drifting = SpeedKph > 30f && Mathf.Abs(SlipAngle) > 10f;
        for (int i = 0; i < smoke.Count; i++)
        {
            var emission = smoke[i].emission;
            emission.rateOverTime = drifting ? Mathf.Lerp(8f, 70f, Mathf.InverseLerp(10f, 42f, Mathf.Abs(SlipAngle))) : 0f;
            trails[i].emitting = drifting;
        }
    }

    void OnCollisionEnter(Collision c)
    {
        if (c.relativeVelocity.magnitude > 4f)
        {
            rb.AddForce(c.contacts[0].normal * 900f, ForceMode.Impulse);
        }
    }
}

public class DriftCamera : MonoBehaviour
{
    public Transform target;
    public Rigidbody targetRb;
    Camera cam;
    Vector3 vel;
    Vector3 lookVel;
    Vector3 smoothLook;

    void Awake() { cam = GetComponent<Camera>(); }

    void LateUpdate()
    {
        if (!target || !targetRb) return;
        float speed = targetRb.velocity.magnitude * 3.6f;
        Vector3 localVel = target.InverseTransformDirection(targetRb.velocity);
        float slide = Mathf.Clamp(localVel.x * 0.028f, -1.6f, 1.6f);
        Vector3 desired = target.position - target.forward * Mathf.Lerp(7.2f, 9.3f, Mathf.InverseLerp(0f,180f,speed)) + Vector3.up * 3.0f + target.right * slide;
        transform.position = Vector3.SmoothDamp(transform.position, desired, ref vel, 0.10f);
        Vector3 lookPoint = target.position + target.forward * Mathf.Lerp(4f,8f,Mathf.InverseLerp(0f,180f,speed)) + Vector3.up * 0.75f;
        smoothLook = Vector3.SmoothDamp(smoothLook, lookPoint, ref lookVel, 0.08f);
        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(smoothLook-transform.position, Vector3.up), Time.deltaTime*9f);
        cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, 66f + Mathf.InverseLerp(0f,220f,speed)*14f, Time.deltaTime*4f);
    }
}
