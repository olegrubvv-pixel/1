import bpy, math, os
from mathutils import Vector

OUT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'assets', 'models'))
os.makedirs(OUT, exist_ok=True)

def clear():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)

def mat(name, rgba, rough=0.75):
    m = bpy.data.materials.new(name)
    m.diffuse_color = rgba
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get('Principled BSDF')
    bsdf.inputs['Base Color'].default_value = rgba
    bsdf.inputs['Roughness'].default_value = rough
    return m

def export(name):
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.export_scene.gltf(filepath=os.path.join(OUT, name + '.glb'), export_format='GLB', use_selection=True)

def add_cyl(name, radius, depth, loc, material, vertices=12, rot=(0,0,0)):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc, rotation=rot)
    o=bpy.context.object; o.name=name; o.data.materials.append(material); return o

def add_ico(name, radius, loc, material, scale=(1,1,1), sub=2):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=sub, radius=radius, location=loc)
    o=bpy.context.object; o.name=name; o.scale=scale; o.data.materials.append(material); return o

wood=mat('Wood',(0.34,0.18,0.08,1))
wood2=mat('WoodLight',(0.48,0.27,0.11,1))
green=mat('Needles',(0.06,0.31,0.16,1))
green2=mat('NeedlesLight',(0.10,0.43,0.22,1))
stone=mat('Stone',(0.34,0.39,0.36,1),0.95)
gold=mat('Gold',(1.0,0.62,0.05,1),0.28)

clear()
add_cyl('Trunk',0.34,4.6,(0,0,2.3),wood)
for z,r in [(3.5,1.75),(4.35,1.48),(5.1,1.12)]:
    bpy.ops.mesh.primitive_cone_add(vertices=12, radius1=r, radius2=0.12, depth=2.1, location=(0,0,z))
    bpy.context.object.data.materials.append(green if z<4.5 else green2)
export('tree')

clear()
add_ico('Rock',1.0,(0,0,0.72),stone,scale=(1.18,0.88,0.72),sub=2)
for v in bpy.context.object.data.vertices:
    v.co.x *= 1.0 + 0.06*math.sin(v.co.z*5.0 + v.co.y*3.0)
export('rock')

clear()
add_cyl('Log',0.48,4.4,(0,0,0.5),wood2,vertices=14,rot=(0,math.radians(90),0))
for x in (-2.2,2.2):
    bpy.ops.mesh.primitive_cylinder_add(vertices=14, radius=0.50, depth=0.06, location=(x,0,0.5), rotation=(0,math.radians(90),0))
    bpy.context.object.data.materials.append(wood)
export('log')

clear()
add_ico('BushA',0.9,(-0.45,0,0.65),green2,scale=(1.2,1.0,0.82),sub=2)
add_ico('BushB',0.78,(0.45,0.08,0.63),green,scale=(1.1,1.0,0.9),sub=2)
add_ico('BushC',0.62,(0,0.2,1.08),green2,scale=(1.0,1.0,0.82),sub=2)
export('bush')

clear()
bpy.ops.mesh.primitive_torus_add(major_radius=0.52, minor_radius=0.13, major_segments=20, minor_segments=10, location=(0,0,0))
bpy.context.object.data.materials.append(gold)
export('coin')

print('Generated Blender GLB assets in', OUT)
