# Forest Rush

A mobile-first, fully 3D endless runner inspired by the readability and responsiveness of lane-based runners, but set on a forest trail with original visuals and mechanics.

## Included in this build
- Three-lane 3D forest path, no rails or trains.
- Swipe left/right to switch lanes.
- Swipe up to jump; swipe down to slide.
- Endless procedural forest chunks.
- Rocks, fallen logs and low branches.
- Coins, shield and magnet pickups.
- Increasing speed and persistent best score.
- Stylized 3D lighting, fog, trees, bushes and character.
- Blender Python asset generator for GLB environment props.
- Android export preset and GitHub Actions APK pipeline.

## Desktop test
Open the project in Godot 4.4+ and run `main.tscn`. Arrow keys/WASD work for quick testing.

## Blender assets
Run:
`blender --background --python tools/generate_assets.py`

## Android
The GitHub workflow generates Blender assets and exports a debug ARM64 APK using Godot.
