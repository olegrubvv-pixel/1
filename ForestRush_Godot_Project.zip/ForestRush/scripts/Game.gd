extends Node3D

const LANE_X := [-2.45, 0.0, 2.45]
const CHUNK_LENGTH := 28.0
const CHUNK_COUNT := 8
const START_SPEED := 13.5
const MAX_SPEED := 27.0
const GRAVITY := 27.0
const JUMP_VELOCITY := 10.7

var rng := RandomNumberGenerator.new()
var world_root: Node3D
var runner: Node3D
var runner_visual: Node3D
var arm_l: Node3D
var arm_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var camera: Camera3D
var score_label: Label
var coin_label: Label
var best_label: Label
var menu_panel: Control
var game_over_panel: Control
var pause_button: Button

var state := "menu"
var lane := 1
var lane_target_x := 0.0
var vertical_velocity := 0.0
var runner_y := 0.0
var sliding := false
var slide_timer := 0.0
var speed := START_SPEED
var distance_run := 0.0
var coins := 0
var best := 0
var run_phase := 0.0
var touch_start := Vector2.ZERO
var touch_active := false
var chunks: Array[Node3D] = []
var shield_time := 0.0
var magnet_time := 0.0

func _ready() -> void:
    rng.randomize()
    _load_best()
    _build_world()
    _build_runner()
    _build_ui()
    _seed_chunks()
    _show_menu()

func _process(delta: float) -> void:
    if state == "running":
        _update_game(delta)
    elif state == "menu":
        _animate_runner(delta, 0.35)
    elif state == "game_over":
        _animate_runner(delta, 0.12)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            touch_start = event.position
            touch_active = true
        elif touch_active:
            touch_active = false
            _handle_swipe(event.position - touch_start)
    elif event is InputEventKey and event.pressed:
        if event.keycode == KEY_LEFT or event.keycode == KEY_A:
            _change_lane(-1)
        elif event.keycode == KEY_RIGHT or event.keycode == KEY_D:
            _change_lane(1)
        elif event.keycode == KEY_UP or event.keycode == KEY_W or event.keycode == KEY_SPACE:
            _jump()
        elif event.keycode == KEY_DOWN or event.keycode == KEY_S:
            _slide()
        elif event.keycode == KEY_ENTER and state != "running":
            _start_run()

func _build_world() -> void:
    world_root = Node3D.new()
    world_root.name = "World"
    add_child(world_root)

    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_COLOR
    environment.background_color = Color("7db7c8")
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color("cce9d4")
    environment.ambient_light_energy = 0.82
    environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    environment.fog_enabled = true
    environment.fog_light_color = Color("bfe3d0")
    environment.fog_light_energy = 0.72
    environment.fog_density = 0.012
    environment.fog_height = 0.0
    environment.fog_height_density = 0.18
    env.environment = environment
    add_child(env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-52.0, -28.0, 0.0)
    sun.light_color = Color("fff2c1")
    sun.light_energy = 1.15
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 65.0
    add_child(sun)

    camera = Camera3D.new()
    camera.position = Vector3(0.0, 4.8, 8.3)
    camera.fov = 58.0
    add_child(camera)
    camera.look_at(Vector3(0.0, 1.55, -8.5), Vector3.UP)

func _build_runner() -> void:
    runner = Node3D.new()
    runner.name = "Runner"
    runner.position = Vector3(0.0, 0.0, 0.0)
    add_child(runner)

    runner_visual = Node3D.new()
    runner_visual.name = "Visual"
    runner.add_child(runner_visual)

    var skin := _mat(Color("f0a56c"), 0.45)
    var shirt := _mat(Color("ec5a4f"), 0.38)
    var dark := _mat(Color("183544"), 0.34)
    var shoe := _mat(Color("f4f0df"), 0.28)
    var hair := _mat(Color("3a261d"), 0.48)
    var pack := _mat(Color("f3b93f"), 0.36)

    _mesh_box(runner_visual, Vector3(1.2, 1.55, 0.62), Vector3(0, 1.95, 0), shirt, Vector3(0,0,0), "Torso")
    _mesh_sphere(runner_visual, Vector3(0.63,0.67,0.61), Vector3(0,3.15,0), skin, "Head")
    _mesh_sphere(runner_visual, Vector3(0.68,0.24,0.64), Vector3(0,3.62,-0.02), hair, "Hair")
    _mesh_box(runner_visual, Vector3(0.78, 0.92, 0.34), Vector3(0,2.05,0.48), pack, Vector3(-7,0,0), "Backpack")

    arm_l = Node3D.new(); arm_l.position = Vector3(-0.78,2.65,0); runner_visual.add_child(arm_l)
    arm_r = Node3D.new(); arm_r.position = Vector3(0.78,2.65,0); runner_visual.add_child(arm_r)
    _mesh_capsule(arm_l, 0.18, 1.28, Vector3(0,-0.55,0), skin, "ArmMesh")
    _mesh_capsule(arm_r, 0.18, 1.28, Vector3(0,-0.55,0), skin, "ArmMesh")

    leg_l = Node3D.new(); leg_l.position = Vector3(-0.34,1.25,0); runner_visual.add_child(leg_l)
    leg_r = Node3D.new(); leg_r.position = Vector3(0.34,1.25,0); runner_visual.add_child(leg_r)
    _mesh_capsule(leg_l, 0.24, 1.42, Vector3(0,-0.58,0), dark, "LegMesh")
    _mesh_capsule(leg_r, 0.24, 1.42, Vector3(0,-0.58,0), dark, "LegMesh")
    _mesh_box(leg_l, Vector3(0.5,0.28,0.78), Vector3(0,-1.27,-0.13), shoe, Vector3(0,0,0), "Shoe")
    _mesh_box(leg_r, Vector3(0.5,0.28,0.78), Vector3(0,-1.27,-0.13), shoe, Vector3(0,0,0), "Shoe")

    runner_visual.scale = Vector3.ONE * 0.72
    runner_visual.position.y = 0.02

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)

    var hud := Control.new()
    hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(hud)

    var top_bar := HBoxContainer.new()
    top_bar.position = Vector2(24, 28)
    top_bar.size = Vector2(672, 74)
    top_bar.add_theme_constant_override("separation", 14)
    hud.add_child(top_bar)

    score_label = _pill_label("0 m", 25, Vector2(220,64))
    coin_label = _pill_label("● 0", 25, Vector2(180,64))
    best_label = _pill_label("BEST %d" % best, 20, Vector2(190,64))
    top_bar.add_child(score_label)
    top_bar.add_child(coin_label)
    top_bar.add_child(best_label)

    pause_button = Button.new()
    pause_button.text = "Ⅱ"
    pause_button.position = Vector2(625, 112)
    pause_button.size = Vector2(70, 70)
    pause_button.add_theme_font_size_override("font_size", 28)
    pause_button.pressed.connect(_toggle_pause)
    hud.add_child(pause_button)
    pause_button.hide()

    menu_panel = _full_panel(hud, Color(0.04,0.10,0.08,0.64))
    var title := Label.new()
    title.text = "FOREST\nRUSH"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.position = Vector2(80, 205)
    title.size = Vector2(560, 210)
    title.add_theme_font_size_override("font_size", 70)
    title.add_theme_color_override("font_color", Color("fff4c7"))
    title.add_theme_color_override("font_shadow_color", Color(0,0,0,0.38))
    title.add_theme_constant_override("shadow_offset_x", 4)
    title.add_theme_constant_override("shadow_offset_y", 6)
    menu_panel.add_child(title)

    var subtitle := Label.new()
    subtitle.text = "Беги по лесной тропе • уклоняйся • прыгай"
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    subtitle.position = Vector2(55, 450)
    subtitle.size = Vector2(610, 60)
    subtitle.add_theme_font_size_override("font_size", 22)
    subtitle.add_theme_color_override("font_color", Color("e9f3dd"))
    menu_panel.add_child(subtitle)

    var play := Button.new()
    play.text = "ИГРАТЬ"
    play.position = Vector2(150, 865)
    play.size = Vector2(420, 112)
    play.add_theme_font_size_override("font_size", 34)
    play.pressed.connect(_start_run)
    _style_button(play, Color("efb83d"), Color("f8d56d"))
    menu_panel.add_child(play)

    var help := Label.new()
    help.text = "Свайп ← →  смена дорожки     ↑ прыжок     ↓ подкат"
    help.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    help.position = Vector2(40, 1010)
    help.size = Vector2(640, 80)
    help.add_theme_font_size_override("font_size", 18)
    help.add_theme_color_override("font_color", Color("d4e6cf"))
    menu_panel.add_child(help)

    game_over_panel = _full_panel(hud, Color(0.03,0.06,0.05,0.72))
    var over_title := Label.new()
    over_title.name = "Title"
    over_title.text = "ЗАБЕГ ОКОНЧЕН"
    over_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    over_title.position = Vector2(80, 310)
    over_title.size = Vector2(560, 90)
    over_title.add_theme_font_size_override("font_size", 42)
    over_title.add_theme_color_override("font_color", Color("fff0ba"))
    game_over_panel.add_child(over_title)

    var result := Label.new()
    result.name = "Result"
    result.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    result.position = Vector2(70, 430)
    result.size = Vector2(580, 160)
    result.add_theme_font_size_override("font_size", 30)
    result.add_theme_color_override("font_color", Color.WHITE)
    game_over_panel.add_child(result)

    var retry := Button.new()
    retry.text = "ЕЩЁ РАЗ"
    retry.position = Vector2(150, 710)
    retry.size = Vector2(420, 108)
    retry.add_theme_font_size_override("font_size", 32)
    retry.pressed.connect(_start_run)
    _style_button(retry, Color("efb83d"), Color("f8d56d"))
    game_over_panel.add_child(retry)
    game_over_panel.hide()

func _seed_chunks() -> void:
    for c in chunks:
        if is_instance_valid(c): c.queue_free()
    chunks.clear()
    for i in range(CHUNK_COUNT):
        chunks.append(_create_chunk(-i * CHUNK_LENGTH))

func _create_chunk(z_pos: float) -> Node3D:
    var chunk := Node3D.new()
    chunk.position.z = z_pos
    world_root.add_child(chunk)

    var path_mat := _mat(Color("a87c52"), 0.92)
    var grass_mat := _mat(Color("4f8b4b"), 0.98)
    _mesh_box(chunk, Vector3(7.9,0.16,CHUNK_LENGTH), Vector3(0,-0.12,-CHUNK_LENGTH*0.5), path_mat, Vector3.ZERO, "Trail")
    _mesh_box(chunk, Vector3(7.0,0.22,CHUNK_LENGTH), Vector3(-7.45,-0.15,-CHUNK_LENGTH*0.5), grass_mat, Vector3.ZERO, "GrassL")
    _mesh_box(chunk, Vector3(7.0,0.22,CHUNK_LENGTH), Vector3(7.45,-0.15,-CHUNK_LENGTH*0.5), grass_mat, Vector3.ZERO, "GrassR")

    for side in [-1, 1]:
        for i in range(9):
            var z := -2.0 - i * 3.0 + rng.randf_range(-0.65,0.65)
            var x: float = float(side) * rng.randf_range(5.0, 9.6)
            _spawn_tree(chunk, Vector3(x,0,z), rng.randf_range(0.78,1.3))
        for i in range(5):
            var bx: float = float(side) * rng.randf_range(4.6,8.4)
            var bz := rng.randf_range(-CHUNK_LENGTH+1.0,-1.0)
            _spawn_bush(chunk, Vector3(bx,0,bz), rng.randf_range(0.7,1.3))

    _populate_chunk(chunk)
    return chunk

func _populate_chunk(chunk: Node3D) -> void:
    var used: Array[int] = []
    for row in range(4):
        var z := -6.0 - row * 5.2 + rng.randf_range(-0.6,0.6)
        if rng.randf() < 0.72:
            var blocked := rng.randi_range(0,2)
            used.append(blocked)
            _spawn_obstacle(chunk, blocked, z, rng.randi_range(0,2))
            if rng.randf() < 0.22:
                var second := (blocked + rng.randi_range(1,2)) % 3
                _spawn_obstacle(chunk, second, z + rng.randf_range(-0.25,0.25), rng.randi_range(0,2))
        var coin_lane := rng.randi_range(0,2)
        if rng.randf() < 0.86:
            for c in range(rng.randi_range(2,5)):
                _spawn_coin(chunk, coin_lane, z - 1.1 - c * 1.05)
    if rng.randf() < 0.13:
        _spawn_powerup(chunk, rng.randi_range(0,2), -rng.randf_range(10,25), "shield" if rng.randf() < 0.5 else "magnet")

func _spawn_tree(parent: Node3D, pos: Vector3, s: float) -> void:
    if ResourceLoader.exists("res://assets/models/tree.glb"):
        var scene = load("res://assets/models/tree.glb")
        if scene is PackedScene:
            var n: Node3D = scene.instantiate()
            n.position = pos
            n.scale = Vector3.ONE * s
            n.rotation.y = rng.randf_range(-PI,PI)
            parent.add_child(n)
            return
    var n := Node3D.new(); n.position = pos; n.scale = Vector3.ONE*s; parent.add_child(n)
    _mesh_cylinder(n,0.30,0.48,4.1,Vector3(0,2.05,0),_mat(Color("6d4b31"),0.9),"Trunk")
    _mesh_sphere(n,Vector3(1.55,1.2,1.55),Vector3(0,4.1,0),_mat(Color("2d7147"),0.92),"CrownA")
    _mesh_sphere(n,Vector3(1.15,1.0,1.15),Vector3(-0.6,4.8,0.2),_mat(Color("3b8e55"),0.92),"CrownB")

func _spawn_bush(parent: Node3D, pos: Vector3, s: float) -> void:
    if ResourceLoader.exists("res://assets/models/bush.glb"):
        var scene = load("res://assets/models/bush.glb")
        if scene is PackedScene:
            var inst: Node3D = scene.instantiate()
            inst.position = pos
            inst.scale = Vector3.ONE * s
            inst.rotation.y = rng.randf_range(-PI, PI)
            parent.add_child(inst)
            return
    var n := Node3D.new(); n.position = pos; n.scale = Vector3.ONE*s; parent.add_child(n)
    _mesh_sphere(n,Vector3(0.8,0.58,0.7),Vector3(0,0.56,0),_mat(Color("3a7f46"),0.95),"Bush")
    _mesh_sphere(n,Vector3(0.52,0.43,0.5),Vector3(0.55,0.65,0.08),_mat(Color("5b9d50"),0.95),"Bush2")

func _spawn_obstacle(parent: Node3D, lane_idx: int, z: float, kind: int) -> void:
    var n := Node3D.new()
    n.position = Vector3(LANE_X[lane_idx],0,z)
    n.add_to_group("obstacle")
    n.set_meta("kind",kind)
    n.set_meta("hit",false)
    parent.add_child(n)
    if kind == 0:
        if ResourceLoader.exists("res://assets/models/rock.glb"):
            var rock_scene = load("res://assets/models/rock.glb")
            if rock_scene is PackedScene:
                var rock: Node3D = rock_scene.instantiate(); rock.scale = Vector3.ONE*0.82; n.add_child(rock)
            else:
                _mesh_sphere(n,Vector3(0.78,0.78,0.68),Vector3(0,0.64,0),_mat(Color("788276"),0.96),"Rock")
        else:
            _mesh_sphere(n,Vector3(0.78,0.78,0.68),Vector3(0,0.64,0),_mat(Color("788276"),0.96),"Rock")
        n.rotation.y = rng.randf_range(-PI,PI)
    elif kind == 1:
        if ResourceLoader.exists("res://assets/models/log.glb"):
            var log_scene = load("res://assets/models/log.glb")
            if log_scene is PackedScene:
                var log_obj: Node3D = log_scene.instantiate(); log_obj.scale = Vector3.ONE*0.82; n.add_child(log_obj)
            else:
                _mesh_cylinder(n,0.42,0.48,4.2,Vector3(0,0.48,0),_mat(Color("845a36"),0.95),"Log")
                n.rotation_degrees.z = 90
        else:
            _mesh_cylinder(n,0.42,0.48,4.2,Vector3(0,0.48,0),_mat(Color("845a36"),0.95),"Log")
            n.rotation_degrees.z = 90
    else:
        _mesh_cylinder(n,0.23,0.31,4.2,Vector3(0,1.82,0),_mat(Color("725033"),0.95),"Branch")
        n.rotation_degrees.z = 90
        _mesh_sphere(n,Vector3(0.58,0.38,0.55),Vector3(-1.55,1.95,0),_mat(Color("477c45"),0.94),"Leaves")

func _spawn_coin(parent: Node3D, lane_idx: int, z: float) -> void:
    var n := Node3D.new()
    n.position = Vector3(LANE_X[lane_idx],1.15,z)
    n.add_to_group("coin")
    n.set_meta("taken",false)
    parent.add_child(n)
    if ResourceLoader.exists("res://assets/models/coin.glb"):
        var coin_scene = load("res://assets/models/coin.glb")
        if coin_scene is PackedScene:
            var coin_obj: Node3D = coin_scene.instantiate(); coin_obj.rotation_degrees.x=90; coin_obj.scale=Vector3.ONE*0.82; n.add_child(coin_obj)
            return
    var mesh := TorusMesh.new(); mesh.inner_radius=0.22; mesh.outer_radius=0.48; mesh.rings=14; mesh.ring_segments=10
    var mi := MeshInstance3D.new(); mi.mesh=mesh; mi.material_override=_mat(Color("ffd34d"),0.24); mi.rotation_degrees.x=90; n.add_child(mi)

func _spawn_powerup(parent: Node3D, lane_idx: int, z: float, kind: String) -> void:
    var n := Node3D.new()
    n.position = Vector3(LANE_X[lane_idx],1.25,z)
    n.add_to_group("powerup")
    n.set_meta("kind",kind)
    n.set_meta("taken",false)
    parent.add_child(n)
    var color := Color("68d5ff") if kind == "shield" else Color("ff6fb5")
    _mesh_sphere(n,Vector3(0.48,0.48,0.48),Vector3.ZERO,_mat(color,0.18),"Orb")

func _update_game(delta: float) -> void:
    speed = min(MAX_SPEED, START_SPEED + distance_run * 0.0062)
    distance_run += speed * delta
    lane_target_x = LANE_X[lane]
    runner.position.x = lerp(runner.position.x, lane_target_x, 1.0 - exp(-14.0*delta))

    if runner_y > 0.0 or vertical_velocity > 0.0:
        vertical_velocity -= GRAVITY * delta
        runner_y += vertical_velocity * delta
        if runner_y <= 0.0:
            runner_y = 0.0
            vertical_velocity = 0.0
    runner.position.y = runner_y

    if sliding:
        slide_timer -= delta
        if slide_timer <= 0.0:
            sliding = false
        runner_visual.scale = runner_visual.scale.lerp(Vector3(0.72,0.43,0.78), 1.0-exp(-16.0*delta))
        runner_visual.position.y = lerp(runner_visual.position.y,0.03,1.0-exp(-16.0*delta))
    else:
        runner_visual.scale = runner_visual.scale.lerp(Vector3.ONE*0.72,1.0-exp(-16.0*delta))

    if shield_time > 0.0: shield_time -= delta
    if magnet_time > 0.0: magnet_time -= delta

    for chunk in chunks:
        if is_instance_valid(chunk): chunk.position.z += speed*delta
    _recycle_chunks()
    _animate_runner(delta, clamp(speed/START_SPEED,1.0,1.75))
    _animate_pickups(delta)
    _check_collisions()
    _update_hud()

    camera.position.x = lerp(camera.position.x, runner.position.x*0.15, 1.0-exp(-4.0*delta))
    camera.position.y = lerp(camera.position.y, 4.8 + runner_y*0.12, 1.0-exp(-4.0*delta))

func _animate_runner(delta: float, pace: float) -> void:
    run_phase += delta * 10.5 * pace
    var swing := sin(run_phase) * 0.72
    if not sliding:
        arm_l.rotation.x = swing
        arm_r.rotation.x = -swing
        leg_l.rotation.x = -swing*0.72
        leg_r.rotation.x = swing*0.72
        runner_visual.rotation.z = sin(run_phase*0.5)*0.025
        if state == "running" and runner_y <= 0.01:
            runner_visual.position.y = 0.04 + abs(sin(run_phase))*0.055
    else:
        arm_l.rotation.x = -0.9
        arm_r.rotation.x = -0.9
        leg_l.rotation.x = 0.78
        leg_r.rotation.x = 0.78

func _animate_pickups(delta: float) -> void:
    for n in get_tree().get_nodes_in_group("coin"):
        if is_instance_valid(n) and n.visible:
            n.rotation.y += delta*5.6
            if magnet_time > 0.0:
                var gp: Vector3 = n.global_position
                if gp.distance_to(runner.global_position + Vector3(0,1.1,0)) < 6.5:
                    gp = gp.lerp(runner.global_position + Vector3(0,1.1,0), 1.0-exp(-8.0*delta))
                    n.global_position = gp
    for n in get_tree().get_nodes_in_group("powerup"):
        if is_instance_valid(n) and n.visible:
            n.rotation.y += delta*2.8
            n.position.y = 1.25 + sin(run_phase*0.45 + n.position.z)*0.12

func _check_collisions() -> void:
    var px := runner.global_position.x
    for n in get_tree().get_nodes_in_group("coin"):
        if not is_instance_valid(n) or not n.visible: continue
        var p: Vector3 = n.global_position
        if abs(p.z) < 0.85 and abs(p.x-px) < 0.9 and abs((runner_y+1.1)-p.y) < 1.25:
            n.visible = false
            coins += 1
    for n in get_tree().get_nodes_in_group("powerup"):
        if not is_instance_valid(n) or not n.visible: continue
        var p: Vector3 = n.global_position
        if abs(p.z) < 0.9 and abs(p.x-px) < 0.9:
            n.visible = false
            if str(n.get_meta("kind")) == "shield": shield_time = 7.0
            else: magnet_time = 8.0
    for n in get_tree().get_nodes_in_group("obstacle"):
        if not is_instance_valid(n) or bool(n.get_meta("hit")): continue
        var p: Vector3 = n.global_position
        if abs(p.z) < 0.72 and abs(p.x-px) < 0.82:
            var kind := int(n.get_meta("kind"))
            var safe := false
            if kind == 2:
                safe = sliding
            else:
                safe = runner_y > 1.05
            if not safe:
                n.set_meta("hit",true)
                if shield_time > 0.0:
                    shield_time = 0.0
                    n.visible = false
                else:
                    _game_over()
                    return

func _recycle_chunks() -> void:
    for i in range(chunks.size()):
        var c := chunks[i]
        if is_instance_valid(c) and c.position.z > 32.0:
            var min_z := 0.0
            for other in chunks:
                if is_instance_valid(other): min_z = min(min_z, other.position.z)
            c.queue_free()
            chunks[i] = _create_chunk(min_z - CHUNK_LENGTH)

func _handle_swipe(delta: Vector2) -> void:
    if state == "menu" or state == "game_over":
        return
    if state == "paused":
        return
    if delta.length() < 34.0: return
    if abs(delta.x) > abs(delta.y):
        _change_lane(1 if delta.x > 0.0 else -1)
    else:
        if delta.y < 0.0: _jump()
        else: _slide()

func _change_lane(dir: int) -> void:
    if state != "running": return
    lane = clamp(lane + dir,0,2)

func _jump() -> void:
    if state != "running": return
    if runner_y <= 0.03 and not sliding:
        vertical_velocity = JUMP_VELOCITY

func _slide() -> void:
    if state != "running": return
    if runner_y < 0.3:
        sliding = true
        slide_timer = 0.72

func _start_run() -> void:
    state = "running"
    lane = 1
    runner.position = Vector3(0,0,0)
    runner_y = 0.0
    vertical_velocity = 0.0
    speed = START_SPEED
    distance_run = 0.0
    coins = 0
    sliding = false
    shield_time = 0.0
    magnet_time = 0.0
    _seed_chunks()
    menu_panel.hide()
    game_over_panel.hide()
    pause_button.show()
    get_tree().paused = false

func _game_over() -> void:
    state = "game_over"
    pause_button.hide()
    var current := int(distance_run)
    if current > best:
        best = current
        _save_best()
    best_label.text = "BEST %d" % best
    var result: Label = game_over_panel.get_node("Result")
    result.text = "%d м\n%d монет" % [current, coins]
    game_over_panel.show()

func _show_menu() -> void:
    state = "menu"
    pause_button.hide()
    game_over_panel.hide()
    menu_panel.show()

func _toggle_pause() -> void:
    if state == "running":
        state = "paused"
        get_tree().paused = true
        pause_button.process_mode = Node.PROCESS_MODE_ALWAYS
        pause_button.text = "▶"
    elif state == "paused":
        get_tree().paused = false
        state = "running"
        pause_button.text = "Ⅱ"

func _update_hud() -> void:
    score_label.text = "%d m" % int(distance_run)
    var extra := ""
    if shield_time > 0.0: extra += "  ◇"
    if magnet_time > 0.0: extra += "  M"
    coin_label.text = "● %d%s" % [coins, extra]

func _load_best() -> void:
    var cfg := ConfigFile.new()
    if cfg.load("user://forest_rush.cfg") == OK:
        best = int(cfg.get_value("score","best",0))

func _save_best() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("score","best",best)
    cfg.save("user://forest_rush.cfg")

func _mat(color: Color, rough: float) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = rough
    m.metallic = 0.0
    return m

func _mesh_box(parent: Node, size: Vector3, pos: Vector3, material: Material, rot: Vector3, name_text: String) -> MeshInstance3D:
    var mesh := BoxMesh.new(); mesh.size = size
    var mi := MeshInstance3D.new(); mi.name=name_text; mi.mesh=mesh; mi.position=pos; mi.rotation_degrees=rot; mi.material_override=material
    parent.add_child(mi)
    return mi

func _mesh_sphere(parent: Node, scale_v: Vector3, pos: Vector3, material: Material, name_text: String) -> MeshInstance3D:
    var mesh := SphereMesh.new(); mesh.radius=1.0; mesh.height=2.0; mesh.radial_segments=16; mesh.rings=8
    var mi := MeshInstance3D.new(); mi.name=name_text; mi.mesh=mesh; mi.scale=scale_v; mi.position=pos; mi.material_override=material
    parent.add_child(mi)
    return mi

func _mesh_capsule(parent: Node, radius: float, height: float, pos: Vector3, material: Material, name_text: String) -> MeshInstance3D:
    var mesh := CapsuleMesh.new(); mesh.radius=radius; mesh.height=height; mesh.radial_segments=12; mesh.rings=4
    var mi := MeshInstance3D.new(); mi.name=name_text; mi.mesh=mesh; mi.position=pos; mi.material_override=material
    parent.add_child(mi)
    return mi

func _mesh_cylinder(parent: Node, top_radius: float, bottom_radius: float, height: float, pos: Vector3, material: Material, name_text: String) -> MeshInstance3D:
    var mesh := CylinderMesh.new(); mesh.top_radius=top_radius; mesh.bottom_radius=bottom_radius; mesh.height=height; mesh.radial_segments=12
    var mi := MeshInstance3D.new(); mi.name=name_text; mi.mesh=mesh; mi.position=pos; mi.material_override=material
    parent.add_child(mi)
    return mi

func _pill_label(text_value: String, fs: int, min_size: Vector2) -> Label:
    var l := Label.new(); l.text=text_value; l.custom_minimum_size=min_size; l.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; l.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
    l.add_theme_font_size_override("font_size",fs); l.add_theme_color_override("font_color",Color.WHITE)
    var sb := StyleBoxFlat.new(); sb.bg_color=Color(0.03,0.09,0.07,0.72); sb.corner_radius_top_left=22; sb.corner_radius_top_right=22; sb.corner_radius_bottom_left=22; sb.corner_radius_bottom_right=22
    l.add_theme_stylebox_override("normal",sb)
    return l

func _full_panel(parent: Control, color: Color) -> Control:
    var panel := Panel.new(); panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var sb := StyleBoxFlat.new(); sb.bg_color=color
    panel.add_theme_stylebox_override("panel",sb); parent.add_child(panel)
    return panel

func _style_button(button: Button, normal: Color, hover: Color) -> void:
    var a := StyleBoxFlat.new(); a.bg_color=normal; a.corner_radius_top_left=34; a.corner_radius_top_right=34; a.corner_radius_bottom_left=34; a.corner_radius_bottom_right=34; a.shadow_color=Color(0,0,0,0.25); a.shadow_size=10
    var b: StyleBoxFlat = a.duplicate() as StyleBoxFlat; b.bg_color=hover
    button.add_theme_stylebox_override("normal",a); button.add_theme_stylebox_override("hover",b); button.add_theme_stylebox_override("pressed",b)
    button.add_theme_color_override("font_color",Color("183544")); button.add_theme_color_override("font_hover_color",Color("183544")); button.add_theme_color_override("font_pressed_color",Color("183544"))
